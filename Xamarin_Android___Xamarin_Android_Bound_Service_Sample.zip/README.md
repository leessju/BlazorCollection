---
name: Xamarin.Android - Xamarin.Android Bound Service Sample
description: This directory holds the sample project from the creating a bound service section of the Creating Services guide for Xamarin.Android....
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: applicationfundamentals-servicesamples-boundservicedemo
---
# Xamarin.Android Bound Service Sample

This directory holds the sample project from the [creating a bound service section](https://docs.microsoft.com/xamarin/android/app-fundamentals/services/creating-a-service/bound-services) of the [Creating Services](https://docs.microsoft.com/xamarin/android/app-fundamentals/services/) guide for Xamarin.Android.

![Android app](Screenshots/bound-service.png)
